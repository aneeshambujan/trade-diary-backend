from fastapi import FastAPI
from pymongo import MongoClient
import os

app = FastAPI()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["trade_diary"]
trades = db["trades"]

@app.get("/")
def root():
    return {"message": "Trade Diary Backend Running"}

@app.get("/trades")
def get_trades():
    return list(trades.find({}, {"_id": 0}))
