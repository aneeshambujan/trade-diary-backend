# Trade Diary Backend (FastAPI)

Backend for the Trade Diary app.